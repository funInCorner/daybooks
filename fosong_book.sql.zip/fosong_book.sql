-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 04 月 06 日 21:04
-- 服务器版本: 5.5.20
-- PHP 版本: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `fosong_book`
--

-- --------------------------------------------------------

--
-- 表的结构 `book_daysentence`
--

CREATE TABLE IF NOT EXISTS `book_daysentence` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `showdate` date NOT NULL COMMENT '显示日期',
  `engsen` varchar(300) CHARACTER SET utf8 NOT NULL COMMENT '英文句子',
  `scsen` varchar(300) CHARACTER SET utf8 NOT NULL COMMENT '中文句子',
  `desc` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '描述',
  `showimg` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '显示的图片',
  `senfrom` varchar(65) CHARACTER SET utf8 NOT NULL COMMENT '网页原来链接',
  `readurl` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '阅读路径',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `book_daysentence`
--

INSERT INTO `book_daysentence` (`sid`, `showdate`, `engsen`, `scsen`, `desc`, `showimg`, `senfrom`, `readurl`) VALUES
(1, '2014-03-31', 'Perseverance is not a long race; it is many short races one after another.', '坚持不懈不是一个长跑，而是一个接着一个的短跑！(Walter Elliot)', '奋斗就是：每一天都很难，可一年一年却越来越容易！不奋斗就是：每一天都很容易，可一年一年却越来越难！人生就是这样，眉毛上的汗水与眉毛下的泪水，总要选择一样！致在奋斗的你！', 'http://cdn.iciba.com/news/word/2014-03-31.jpg', 'http://news.iciba.com/dailysentence/detail-852.html', 'http://news.iciba.com/admin/tts/2014-03-31.mp3'),
(2, '2014-03-30', 'My life didn''t please me, so I created my life.', '我的生活不曾取悦于我，所以我创造了自己的生活。(Coco Chanel)', '无论你多少岁，读多少书，生得美不美，都要做个闪闪发光的漂亮姑娘。开心的时候要漂亮，不开心的时候更要漂亮！漂亮如果有秘诀，那就是：狠狠宠爱自己 ！', 'http://cdn.iciba.com/news/word/2014-03-30.jpg', 'http://news.iciba.com/dailysentence/detail-851.html', 'http://news.iciba.com/admin/tts/2014-03-30.mp3');

-- --------------------------------------------------------

--
-- 表的结构 `book_everydaymusic`
--

CREATE TABLE IF NOT EXISTS `book_everydaymusic` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `msuicUrl` varchar(85) DEFAULT NULL COMMENT '歌曲链接地址',
  `musicName` varchar(30) NOT NULL COMMENT '歌曲名称',
  `songer` varchar(30) DEFAULT NULL COMMENT '歌手名称',
  `songertx` varchar(35) DEFAULT NULL COMMENT '歌手头像',
  `showdate` date DEFAULT NULL COMMENT '日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='每日歌曲表' AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `book_everydaymusic`
--

INSERT INTO `book_everydaymusic` (`id`, `msuicUrl`, `musicName`, `songer`, `songertx`, `showdate`) VALUES
(1, 'http://mp3.9ku.com/file2/402/401770.mp3', 'all for you', 'Ace Of Base', '', '2014-02-09'),
(2, 'http://mp3.9ku.com/file2/449/448078.mp3', '刚刚慢摇230', '能上网的曲子', '', '2014-02-08'),
(3, 'http://mp3.9ku.com/file2/199/198038.mp3', 'Rohi Dunya(精神世界)', 'Unknown', '', '2014-02-07'),
(4, 'http://mp3.9ku.com/file2/88/87528.mp3', 'Don''t Lie', 'Black Eyed Peas', '', '2014-02-06'),
(5, 'http://mp3.9ku.com/file2/192/191720.mp3', 'Winter in my heart', 'befour', '', '2014-02-05'),
(6, 'http://mp3.9ku.com/file2/198/197631.mp3', 'Do You Know', 'Enrique', '', '2014-02-04'),
(7, 'http://mp3.9ku.com/file2/198/197363.mp3', 'The apl song', 'Black Eyed ', '', '2014-02-03'),
(8, 'http://mp3.9ku.com/file2/26/25600.mp3', 'beautiful life', 'Ace Of Base', '', '2014-02-02'),
(9, 'http://mp3.9ku.com/file2/85/84730.mp3', 'Rhythm of love', 'Yoomiii', '', '2014-02-01'),
(10, 'http://sc.111ttt.com/up/mp3/330605/B22C01871166B758FC0D26C460EFD1D9.mp3', 'Goodbye', 'JW', '', '2014-02-10'),
(11, 'http://mp3.9ku.com/file2/401/400567.mp3', 'off the hook', 'Jeff Jarvis', '', '2014-02-11'),
(12, 'http://mp3.9ku.com/file2/190/189542.mp3', 'Seven Days', 'Craig David', '', '2014-01-31'),
(13, 'http://mp3.9ku.com/file2/193/192994.mp3', 'something to dream on', 'Dylan Mondegreen', '', '2014-01-30'),
(14, 'http://mp3.9ku.com/mp3/507/506847.mp3', 'Waiting for Love', 'Baker', '', '2014-01-29'),
(15, 'http://mp3.9ku.com/file2/198/197203.mp3', 'Lesson No 1', '摩托罗拉广告曲', 'res/tx/8186.jpg', '2014-03-22'),
(16, 'http://mp3.9ku.com/file2/88/87567.mp3', 'i miss you', 'Darren Hayes — Spin CD1', '', '2014-03-22');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
