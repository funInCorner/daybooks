-- phpMyAdmin SQL Dump
-- version 2.11.10
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 02 月 23 日 21:13
-- 服务器版本: 5.0.77
-- PHP 版本: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `fosong_book`
--

-- --------------------------------------------------------

--
-- 表的结构 `book_daysentence`
--

CREATE TABLE IF NOT EXISTS `book_daysentence` (
  `sid` int(11) default NULL,
  `showdate` date NOT NULL COMMENT '显示日期',
  `engsen` varchar(300) character set utf8 NOT NULL COMMENT '英文句子',
  `scsen` varchar(300) character set utf8 NOT NULL COMMENT '中文句子',
  `desc` varchar(200) character set utf8 NOT NULL COMMENT '描述',
  `showimg` varchar(50) character set utf8 NOT NULL COMMENT '显示的图片'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 导出表中的数据 `book_daysentence`
--


-- --------------------------------------------------------

--
-- 表的结构 `book_everydaymusic`
--

CREATE TABLE IF NOT EXISTS `book_everydaymusic` (
  `id` int(11) NOT NULL auto_increment COMMENT 'id',
  `msuicUrl` varchar(85) NOT NULL COMMENT '歌曲链接地址',
  `musicName` varchar(30) NOT NULL COMMENT '歌曲名称',
  `songer` varchar(30) NOT NULL COMMENT '歌手名称',
  `showdate` date NOT NULL COMMENT '日期',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='每日歌曲表' AUTO_INCREMENT=15 ;

--
-- 导出表中的数据 `book_everydaymusic`
--

INSERT INTO `book_everydaymusic` (`id`, `msuicUrl`, `musicName`, `songer`, `showdate`) VALUES
(1, 'http://mp3.9ku.com/file2/402/401770.mp3', 'all for you', 'Ace Of Base', '2014-02-09'),
(2, 'http://mp3.9ku.com/file2/449/448078.mp3', '刚刚慢摇230', '能上网的曲子', '2014-02-08'),
(3, 'http://mp3.9ku.com/file2/199/198038.mp3', 'Rohi Dunya(精神世界)', 'Unknown', '2014-02-07'),
(4, 'http://mp3.9ku.com/file2/88/87528.mp3', 'Don''t Lie', 'Black Eyed Peas', '2014-02-06'),
(5, 'http://mp3.9ku.com/file2/192/191720.mp3', 'Winter in my heart', 'befour', '2014-02-05'),
(6, 'http://mp3.9ku.com/file2/198/197631.mp3', 'Do You Know', 'Enrique', '2014-02-04'),
(7, 'http://mp3.9ku.com/file2/198/197363.mp3', 'The apl song', 'Black Eyed ', '2014-02-03'),
(8, 'http://mp3.9ku.com/file2/26/25600.mp3', 'beautiful life', 'Ace Of Base', '2014-02-02'),
(9, 'http://mp3.9ku.com/file2/85/84730.mp3', 'Rhythm of love', 'Yoomiii', '2014-02-01'),
(10, 'http://sc.111ttt.com/up/mp3/330605/B22C01871166B758FC0D26C460EFD1D9.mp3', 'Goodbye', 'JW', '2014-02-10'),
(11, 'http://mp3.9ku.com/file2/401/400567.mp3', 'off the hook', 'Jeff Jarvis', '2014-02-11'),
(12, 'http://mp3.9ku.com/file2/190/189542.mp3', 'Seven Days', 'Craig David', '2014-01-31'),
(13, 'http://mp3.9ku.com/file2/193/192994.mp3', 'something to dream on', 'Dylan Mondegreen', '2014-01-30'),
(14, 'http://mp3.9ku.com/mp3/507/506847.mp3', 'Waiting for Love', 'Baker', '2014-01-29');
